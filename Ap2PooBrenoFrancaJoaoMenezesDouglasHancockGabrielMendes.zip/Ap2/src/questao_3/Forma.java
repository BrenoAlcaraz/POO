package questao_3;

// Classe abstrata Forma que define o método calcularArea() para ser implementado pelas subclasses.
public abstract class Forma {
    public abstract double calcularArea();
}
