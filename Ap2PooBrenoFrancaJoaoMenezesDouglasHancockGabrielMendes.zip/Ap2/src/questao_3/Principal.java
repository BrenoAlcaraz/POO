package questao_3;

//Classe principal para testar as formas geométricas.
public class Principal {
 public static void main(String[] args) {
     Forma circulo = new Circulo(5);
     Forma retangulo = new Retangulo(4, 6);
     Forma triangulo = new Triangulo(3, 7);

     System.out.println("Área do Círculo: " + circulo.calcularArea());
     System.out.println("Área do Retângulo: " + retangulo.calcularArea());
     System.out.println("Área do Triângulo: " + triangulo.calcularArea());
 }
}

