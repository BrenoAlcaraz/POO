package questao_3;

//Classe Circulo que estende Forma e implementa o método calcularArea().
public class Circulo extends Forma {
 private double raio;

 public Circulo(double raio) {
     this.raio = raio;
 }

 @Override
 public double calcularArea() {
     return Math.PI * raio * raio;
 }
}

